// tela.h
// -----------------------------------------------------------------------------
// Desenho da tela. Layout (80 colunas x 24 linhas, o tamanho padrão dos
// terminais):
//
//   linha 1       : mensagem
//   linhas 2..22  : câmera — um pedaço do mapa (39 x 21 células) em volta do
//                   jogador, com zoom 2x (cada célula ocupa 2 colunas)
//   linha 23      : painel de status
//   linha 24      : lembrete dos comandos
// -----------------------------------------------------------------------------
#pragma once

#include <string>
#include <vector>

struct Jogo;
struct Batalha;

const int TELA_COLUNAS = 80;
const int TELA_LINHAS = 24;

// Quantas células do mapa a câmera mostra. Ímpar, para o jogador ficar
// exatamente no meio. 39 células x 2 colunas = 78 colunas na tela.
const int CAMERA_LARGURA = 39;
const int CAMERA_ALTURA = 21;

void desenharJogo(const Jogo& jogo);

// Célula do mapa que aparece no canto superior esquerdo da câmera.
void posicaoDaCamera(const Jogo& jogo, int& cameraX, int& cameraY);
void desenharAjuda(const Jogo& jogo);
void desenharHistorico(const Jogo& jogo);
void desenharMorte(const Jogo& jogo);

// Tela de batalha (estilo Pokémon). Desenha o estado atual da batalha.
void desenharBatalha(const Jogo& jogo, const Batalha& batalha);

// Caixa no meio da tela com uma lista de opções (a "cursor" fica destacada).
void desenharMenuEmCaixa(const std::string& titulo, const std::vector<std::string>& opcoes,
                         const std::string& descricao, int cursor);

// Faz o próximo desenho apagar a tela inteira (usado ao sair da batalha).
void forcarLimpezaDaTela();

// Mostra um aviso no meio da tela (ex.: janela pequena demais).
void desenharAviso(const std::string& linha1, const std::string& linha2);
